# Author: Kyun-Seop Bae k@acr.kr
# Last modification: 2017.7.24

UT  = function(x) toupper(gsub("^\\s+|\\s+$", "", x))
